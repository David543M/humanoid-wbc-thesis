/* eslint-disable */
// =========================================================
// SLIDE 10 — Decision 2: Simulator
// =========================================================
function Slide10({ idx, total }) {
  const sims = [
  { name: 'Gazebo', speed: 35, contact: 60, api: 75, free: true, reject: 'Slower than real-time' },
  { name: 'PyBullet', speed: 70, contact: 30, api: 80, free: true, reject: 'Unreliable foot contacts' },
  { name: 'IsaacGym', speed: 95, contact: 75, api: 60, free: false, reject: 'NVIDIA license' },
  { name: 'MuJoCo', speed: 100, contact: 95, api: 95, free: true, choose: true }];


  return (
    <SlideFrame label="Section 4 · Decisions" idx={idx} total={total}>
      <SectionEyebrow kicker="Decision 2 of 4">The simulator</SectionEyebrow>
      <SlideTitle>MuJoCo — fastest, most accurate, most compatible.</SlideTitle>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 60, marginTop: 48, alignItems: 'stretch' }}>
        {/* benchmark */}
        <div style={{ background: C.paperDk, padding: '32px 36px', position: 'relative' }}>
          <CornerTicks color={C.ink} size={18} />
          <div style={{ fontFamily: F.mono, fontSize: 18, letterSpacing: '0.16em', color: C.mute, textTransform: 'uppercase', marginBottom: 20 }}>
            Benchmark · normalized 0–100
          </div>
          {sims.map((s, i) => <SimRow key={i} {...s} />)}
          <div style={{ display: 'flex', gap: 20, marginTop: 22, paddingTop: 16, borderTop: `1px solid ${C.ink}22`, fontFamily: F.mono, fontSize: 16, color: C.mute, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
            <Legend color={C.ink2} label="Speed" />
            <Legend color={C.accent} label="Contact accuracy" />
            <Legend color={C.accent2} label="Python API" />
          </div>
        </div>

        {/* why */}
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {/* MuJoCo screenshot */}
          <div style={{
            position: 'relative', marginBottom: 22,
            background: C.ink, padding: 6
          }}>
            <img src="img/mujoco.png" alt="MuJoCo simulation viewport" style={{
              width: '100%', objectFit: 'cover', display: 'block', height: "365px"
            }} />
            <div style={{
              position: 'absolute', top: 12, left: 14,
              fontFamily: F.mono, fontSize: 11, color: '#ffffffcc', letterSpacing: '0.16em',
              textTransform: 'uppercase', background: '#00000088', padding: '3px 8px'
            }}>
              MuJoCo viewport · 1 kHz
            </div>
          </div>
          <div style={{ fontFamily: F.mono, fontSize: 20, letterSpacing: '0.16em', color: C.accent, textTransform: 'uppercase', marginBottom: 16 }}>
            Why MuJoCo
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <Reason big="< 1 ms" sub="step time → enables 1 kHz control loop" />
            <Reason big="2022" sub="open-sourced by DeepMind · no license cost" />
            <Reason big="3/3" sub="Radosavovic · ASAP · HumanoidBench all use it" />
            <Reason big="∂F/∂q" sub="contact forces inspectable per timestep" />
          </div>
        </div>
      </div>
    </SlideFrame>);

}

function SimRow({ name, speed, contact, api, free, choose, reject }) {
  return (
    <div style={{
      padding: '14px 0',
      borderBottom: `1px solid ${C.ink}22`,
      display: 'grid', gridTemplateColumns: '180px 1fr 1fr 1fr 200px', gap: 20, alignItems: 'center'
    }}>
      <div style={{ fontFamily: F.serif, fontSize: 30, color: choose ? C.accent : C.ink, fontWeight: choose ? 600 : 400 }}>
        {name}
        {choose && <span style={{ marginLeft: 10, fontFamily: F.mono, fontSize: 14, color: C.accent, letterSpacing: '0.16em' }}>✓ CHOSEN</span>}
      </div>
      <Bar v={speed} c={C.ink2} />
      <Bar v={contact} c={C.accent} />
      <Bar v={api} c={C.accent2} />
      <div style={{ fontFamily: F.mono, fontSize: 16, color: choose ? C.accent : C.bad, textAlign: 'right', letterSpacing: '0.04em' }}>
        {choose ? 'all green' : reject}
      </div>
    </div>);

}

function Bar({ v, c }) {
  return (
    <div style={{ position: 'relative', height: 16, background: `${C.ink}10` }}>
      <div style={{ position: 'absolute', top: 0, left: 0, height: '100%', width: `${v}%`, background: c }} />
      <div style={{ position: 'absolute', right: -36, top: -2, fontFamily: F.mono, fontSize: 14, color: C.mute }}>{v}</div>
    </div>);

}

function Legend({ color, label }) {
  return <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><span style={{ width: 18, height: 6, background: color }} />{label}</div>;
}

function Reason({ big, sub }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 18, paddingBottom: 14, borderBottom: `1px solid ${C.ink}22` }}>
      <div style={{ fontFamily: F.serif, fontSize: 56, color: C.accent, lineHeight: 0.95, minWidth: 130 }}>{big}</div>
      <div style={{ fontFamily: F.sans, fontSize: 24, color: C.ink2, lineHeight: 1.3 }}>{sub}</div>
    </div>);

}

// =========================================================
// SLIDE 11 — Decision 3: Architecture
// =========================================================
function Slide11({ idx, total }) {
  return (
    <SlideFrame label="Section 4 · Decisions" idx={idx} total={total}>
      <SectionEyebrow kicker="Decision 3 of 4">The control architecture</SectionEyebrow>
      <SlideTitle>A two-layer hierarchy: theoretically grounded, real-time capable.</SlideTitle>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: 60, marginTop: 48, alignItems: 'stretch' }}>
        {/* DIAGRAM */}
        <div style={{ position: 'relative', background: C.paperDk, padding: '32px 80px 32px 36px' }}>
          <CornerTicks color={C.accent} size={18} />
          <div style={{ fontFamily: F.mono, fontSize: 18, letterSpacing: '0.16em', color: C.mute, textTransform: 'uppercase', marginBottom: 28 }}>
            Two-layer control architecture
          </div>

          <ArchBlock label="INPUT" title="Task references + state estimate" side="in" />
          <ArchArrow signal="goals · q̂, q̇̂" />
          <ArchBlock
            label="LAYER 1 · 100 Hz"
            title="Centroidal MPC"
            sub="Crocoddyl"
            tone="accent" />
          
          <ArchArrow signal="CoM trajectory · contact force refs" />
          <ArchBlock
            label="LAYER 2 · 1 kHz"
            title="QP-WBC"
            sub="Pinocchio + TSID"
            tone="accent2" />
          
          <ArchArrow signal="τ — joint torques (N·m)" />
          <ArchBlock label="PLANT" title="TALOS in MuJoCo" tone="dark" />

          {/* feedback loop — sits in the right gutter we reserved via padding */}
          <svg style={{ position: 'absolute', top: 80, right: 28, width: 36, bottom: 60 }} viewBox="0 0 36 100" preserveAspectRatio="none">
            <path d="M 4 95 L 32 95 L 32 5 L 18 5" fill="none" stroke={C.accent} strokeWidth="2" strokeDasharray="4 4" />
            <polyline points="22,1 18,5 22,9" fill="none" stroke={C.accent} strokeWidth="2" />
          </svg>
          <div style={{
            position: 'absolute', right: 8, top: '50%',
            fontFamily: F.mono, fontSize: 14, color: C.accent, letterSpacing: '0.12em', textTransform: 'uppercase',
            transform: 'translateY(-50%) rotate(-90deg)', transformOrigin: 'center', whiteSpace: 'nowrap'
          }}>
            state feedback
          </div>
        </div>

        {/* WHY */}
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <div style={{ fontFamily: F.mono, fontSize: 18, letterSpacing: '0.16em', color: C.mute, textTransform: 'uppercase', marginBottom: 16 }}>
            Three options · one viable
          </div>
          <RejectRow name="Pure QP-WBC" why="Reactive only · no predictive contact planning" />
          <RejectRow name="Pure MPC" why="Too slow at 1 kHz · joint limits hard" />
          <RejectRow name="End-to-end RL" why="Data-hungry · black-box · not generalizable" />

          <div style={{ marginTop: 28, padding: '22px 26px', background: C.ink, color: C.paperOnDeep, position: 'relative' }}>
            <CornerTicks color={C.accent} size={18} />
            <div style={{ fontFamily: F.mono, fontSize: 16, letterSpacing: '0.16em', color: C.accent, textTransform: 'uppercase', marginBottom: 10 }}>
              Why two layers
            </div>
            <div style={{ fontFamily: F.serif, fontSize: 22, lineHeight: 1.3 }}>
              MPC handles long-horizon contact prediction; QP-WBC enforces strict task hierarchy and joint limits in real time. Both are model-based — interpretable, debuggable, transferable to hardware.
            </div>
            <div style={{ fontFamily: F.mono, fontSize: 14, color: '#ffffffaa', marginTop: 12, letterSpacing: '0.08em' }}>
              Validated on Atlas (Koolen ’16) · HRP-4 (Caron ’19) · ANYmal (Sleiman ’21).
            </div>
          </div>
        </div>
      </div>
    </SlideFrame>);

}

function ArchBlock({ label, title, sub, tone, side }) {
  const palette = tone === 'accent' ? { bg: C.paper, border: C.accent, accent: C.accent } :
  tone === 'accent2' ? { bg: C.paper, border: C.accent2, accent: C.accent2 } :
  tone === 'dark' ? { bg: C.ink, border: C.ink, accent: C.accent, fg: C.paperOnDeep } :
  { bg: C.paper, border: C.ink + '55', accent: C.mute };
  return (
    <div style={{
      padding: '14px 20px', background: palette.bg, color: palette.fg || C.ink,
      border: `2px solid ${palette.border}`,
      display: 'grid', gridTemplateColumns: 'auto 1fr auto', alignItems: 'center', gap: 20,
      width: '92%'
    }}>
      <div style={{ fontFamily: F.mono, fontSize: 14, letterSpacing: '0.16em', color: palette.accent, textTransform: 'uppercase' }}>
        {label}
      </div>
      <div style={{ fontFamily: F.serif, fontSize: 28, lineHeight: 1.05 }}>{title}</div>
      {sub && <div style={{ fontFamily: F.mono, fontSize: 14, color: palette.fg ? '#ffffffaa' : C.mute, letterSpacing: '0.06em' }}>{sub}</div>}
    </div>);

}

function ArchArrow({ signal }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '6px 0 6px 24px' }}>
      <svg width="18" height="32" viewBox="0 0 18 32"><line x1="9" y1="0" x2="9" y2="24" stroke={C.ink} strokeWidth="2" /><polyline points="3,22 9,30 15,22" fill="none" stroke={C.ink} strokeWidth="2" /></svg>
      <span style={{ fontFamily: F.mono, fontSize: 14, color: C.mute, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{signal}</span>
    </div>);

}

function RejectRow({ name, why }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '40px 1fr', gap: 16, padding: '14px 0', borderBottom: `1px solid ${C.ink}22` }}>
      <div style={{ fontFamily: F.mono, fontSize: 22, color: C.bad }}>×</div>
      <div>
        <div style={{ fontFamily: F.serif, fontSize: 28, color: C.ink2, lineHeight: 1.05 }}>{name}</div>
        <div style={{ fontFamily: F.sans, fontSize: 22, color: C.mute, marginTop: 4, lineHeight: 1.3 }}>{why}</div>
      </div>
    </div>);

}

// =========================================================
// SLIDE 12 — Decision 4: Contribution
// =========================================================
function Slide12({ idx, total }) {
  const scenarios = [
  { id: 'S1', name: 'Static balance', diff: 1, tests: 'Postural stability, joint limits' },
  { id: 'S2', name: 'Flat-ground walking', diff: 2, tests: 'Gait, CoM-height regulation' },
  { id: 'S3', name: 'Push recovery', diff: 3, tests: 'Force rejection (10–50 N impulse)' },
  { id: 'S4', name: 'Stair climbing', diff: 4, tests: 'Contact-rich locomotion' },
  { id: 'S5', name: 'Loco-manipulation', diff: 5, tests: 'Walking + arm payload' }];


  return (
    <SlideFrame label="Section 4 · Decisions" idx={idx} total={total}>
      <SectionEyebrow kicker="Decision 4 of 4">The contribution</SectionEyebrow>
      <SlideTitle>Our novelty is not a new algorithm — it's a reproducible protocol.</SlideTitle>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1.1fr 1.5fr', gap: 56, marginTop: 44 }}>
        {/* LEFT — current vs ours */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          <BubbleDiagram tone="bad" label="Status quo" caption="Every paper in its own bubble. No shared protocol. No comparison." />
          <BubbleDiagram tone="good" label="With this thesis" caption="All experiments share S1–S5. Direct, fair comparison becomes possible." />
        </div>

        {/* RIGHT — table */}
        <div style={{ background: C.ink, color: C.paperOnDeep, padding: '32px 36px', position: 'relative' }}>
          <CornerTicks color={C.accent} size={18} />
          <div style={{ fontFamily: F.mono, fontSize: 18, letterSpacing: '0.16em', color: C.accent, textTransform: 'uppercase', marginBottom: 16 }}>
            S1–S5 evaluation protocol
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {scenarios.map((s, i) =>
            <div key={i} style={{
              display: 'grid', gridTemplateColumns: '60px 1fr 160px', gap: 18, alignItems: 'center',
              padding: '18px 0', borderBottom: `1px solid ${'#ffffff20'}`
            }}>
                <div style={{ fontFamily: F.mono, fontSize: 28, color: C.accent, letterSpacing: '0.04em' }}>{s.id}</div>
                <div>
                  <div style={{ fontFamily: F.serif, fontSize: 30, color: C.paperOnDeep, lineHeight: 1.05 }}>{s.name}</div>
                  <div style={{ fontFamily: F.sans, fontSize: 20, color: '#ffffffaa', marginTop: 4 }}>{s.tests}</div>
                </div>
                <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                  {[1, 2, 3, 4, 5].map((d) =>
                <span key={d} style={{
                  width: 16, height: 16, borderRadius: '50%',
                  background: d <= s.diff ? C.accent : '#ffffff22'
                }} />
                )}
                </div>
              </div>
            )}
          </div>
          <div style={{ marginTop: 22, paddingTop: 18, borderTop: `1px solid #ffffff20` }}>
            <div style={{ fontFamily: F.mono, fontSize: 16, letterSpacing: '0.16em', color: C.accent, textTransform: 'uppercase', marginBottom: 8 }}>
              Standardized metrics
            </div>
            <div style={{ fontFamily: F.serif, fontSize: 24, lineHeight: 1.4 }}>
              CoM deviation · ZMP margin · Joint torque RMS · Recovery time · Energy per step
            </div>
          </div>
        </div>
      </div>

      <div style={{ marginTop: 24, fontFamily: F.serif, fontStyle: 'italic', fontSize: 28, color: C.ink2, lineHeight: 1.3 }}>
        Any future team adding a new algorithm runs S1–S5 and immediately knows whether they improved or regressed. This baseline does not exist today.
      </div>
    </SlideFrame>);

}

function BubbleDiagram({ tone, label, caption }) {
  const good = tone === 'good';
  return (
    <div style={{
      flex: 1, background: good ? C.paperDk : C.paperDk,
      padding: '20px 24px', position: 'relative',
      border: `2px solid ${good ? C.ok : C.bad + '88'}`
    }}>
      <div style={{ fontFamily: F.mono, fontSize: 16, letterSpacing: '0.16em', color: good ? C.ok : C.bad, textTransform: 'uppercase', marginBottom: 8 }}>
        {label}
      </div>
      <svg viewBox="0 0 400 130" style={{ width: '100%', height: 130 }}>
        {good ?
        <>
            <rect x="80" y="50" width="240" height="34" fill={C.ink} opacity="0.92" />
            <text x="200" y="73" fontFamily="JetBrains Mono, monospace" fontSize="13" fill={C.accent} textAnchor="middle" letterSpacing="2">S1 · S2 · S3 · S4 · S5</text>
            {[60, 110, 160, 200, 240, 290, 340].map((x, i) =>
          <g key={i}>
                <circle cx={x} cy={20} r="14" fill={C.paper} stroke={C.ink} />
                <line x1={x} y1={34} x2={x} y2={50} stroke={C.ok} strokeWidth="1.5" />
                <line x1={x} y1={84} x2={x} y2={108} stroke={C.ok} strokeWidth="1.5" />
                <circle cx={x} cy={114} r="10" fill={C.ok} opacity="0.5" />
              </g>
          )}
          </> :

        <>
            {[
          [60, 35], [120, 90], [200, 30], [260, 95], [340, 40], [310, 85], [80, 100]].
          map(([x, y], i) =>
          <circle key={i} cx={x} cy={y} r="22" fill={C.paper} stroke={C.bad} strokeWidth="1.5" />
          )}
            <text x="60" y="40" fontFamily="JetBrains Mono, monospace" fontSize="9" textAnchor="middle" fill={C.mute}>paper</text>
            <text x="120" y="95" fontFamily="JetBrains Mono, monospace" fontSize="9" textAnchor="middle" fill={C.mute}>paper</text>
            <text x="200" y="35" fontFamily="JetBrains Mono, monospace" fontSize="9" textAnchor="middle" fill={C.mute}>paper</text>
            <text x="260" y="100" fontFamily="JetBrains Mono, monospace" fontSize="9" textAnchor="middle" fill={C.mute}>paper</text>
            <text x="340" y="45" fontFamily="JetBrains Mono, monospace" fontSize="9" textAnchor="middle" fill={C.mute}>paper</text>
            <text x="310" y="90" fontFamily="JetBrains Mono, monospace" fontSize="9" textAnchor="middle" fill={C.mute}>paper</text>
            <text x="80" y="105" fontFamily="JetBrains Mono, monospace" fontSize="9" textAnchor="middle" fill={C.mute}>paper</text>
          </>
        }
      </svg>
      <div style={{ fontFamily: F.sans, fontSize: 22, color: C.ink2, lineHeight: 1.3, marginTop: 4 }}>
        {caption}
      </div>
    </div>);

}

// =========================================================
// SLIDE 13 — Three gaps
// =========================================================
function Slide13({ idx, total }) {
  const gaps = [
  {
    n: 'Gap 1', color: C.bad,
    title: 'Reproducibility crisis',
    problem: 'No two WBC papers share scenario, metric or platform — cross-paper comparison is impossible. The field cannot tell whether controllers improve over time.',
    answer: 'S1–S5 standardized protocol with fixed metrics. Future papers compare against our baseline.'
  },
  {
    n: 'Gap 2', color: C.warn,
    title: 'Architecture fragmentation',
    problem: 'Model-based (TSID, Crocoddyl) and learning-based (ASAP, Radosavovic) controllers are evaluated in isolation, with no common ground.',
    answer: 'Two-layer MPC + QP-WBC on TALOS in MuJoCo — the same setup RL researchers use. Direct comparison becomes possible.'
  },
  {
    n: 'Gap 3', color: '#6E3F8E',
    title: 'Contact-rich scenarios underexplored',
    problem: '90 % of WBC validation is flat-ground locomotion. Stair climbing and manipulation in simulation before hardware deployment are systematically avoided.',
    answer: 'S4 and S5 explicitly force the controller into contact-rich regimes — with standardized metrics for them.'
  }];

  return (
    <SlideFrame label="Section 5 · Gaps" idx={idx} total={total}>
      <SectionEyebrow kicker="08 · Open problems">Three gaps · three answers</SectionEyebrow>
      <SlideTitle>Three gaps we close.</SlideTitle>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 22, marginTop: 44 }}>
        {gaps.map((g, i) => <GapRow key={i} {...g} />)}
      </div>
    </SlideFrame>);

}

function GapRow({ n, color, title, problem, answer }) {
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '180px 1.4fr 1fr', gap: 0,
      background: C.paperDk, position: 'relative',
      border: `1px solid ${C.ink}22`, borderLeft: `8px solid ${color}`, width: "1700px", height: "175px"
    }}>
      <div style={{ padding: '24px 28px', borderRight: `1px solid ${C.ink}22`, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: "0px", width: "225px", height: "172px" }}>
        <div style={{ fontFamily: F.mono, fontSize: 16, letterSpacing: '0.16em', color, textTransform: 'uppercase' }}>{n}</div>
        <div style={{ fontFamily: F.serif, fontSize: 36, color: C.ink, lineHeight: 1.0, marginTop: 6, width: "176px" }}>{title}</div>
      </div>
      <div style={{ borderRight: `1px solid ${C.ink}22`, width: "886px", borderWidth: "0px", margin: "0px", padding: "24px 0px 24px 60.7999px" }}>
        <div style={{ fontFamily: F.mono, fontSize: 14, letterSpacing: '0.16em', color: C.mute, textTransform: 'uppercase', marginBottom: 8, width: "830px" }}>Problem</div>
        <div style={{ fontFamily: F.sans, fontSize: 24, color: C.ink2, lineHeight: 1.35, borderWidth: "0px", borderStyle: "solid", margin: "0px", width: "776px", padding: "0px" }}>{problem}</div>
      </div>
      <div style={{ padding: '24px 32px', background: C.ink, color: C.paperOnDeep, width: "630px" }}>
        <div style={{ fontFamily: F.mono, fontSize: 14, letterSpacing: '0.16em', color: C.accent, textTransform: 'uppercase', marginBottom: 8 }}>Our answer</div>
        <div style={{ fontFamily: F.serif, fontSize: 26, lineHeight: 1.3 }}>{answer}</div>
      </div>
    </div>);

}

// =========================================================
// SLIDE 14 — What we leave open
// =========================================================
function Slide14({ idx, total }) {
  return (
    <SlideFrame label="Section 5 · Gaps" idx={idx} total={total}>
      <SectionEyebrow kicker="09 · Beyond this thesis">A roadmap for future researchers</SectionEyebrow>
      <SlideTitle>What we leave open — by design.</SlideTitle>
      <div style={{ fontFamily: F.serif, fontStyle: 'italic', fontSize: 32, color: C.ink2, marginTop: 24, maxWidth: 1500, lineHeight: 1.3 }}>
        We are not trying to solve everything. We build the floor — here is what comes next.
      </div>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 28, marginTop: 44 }}>
        <FutureCard
          status="DONE"
          tone="ok"
          level="L1"
          title="Simulation framework + S1–S5 protocol"
          items={[
          'Two-layer MPC + QP-WBC on TALOS',
          'MuJoCo environment, reproducible',
          'Open-source, documented, modular']
          } />
        
        <FutureCard
          status="NEXT · Year 3"
          tone="open"
          level="L2"
          title="Hardware integration"
          items={[
          'Replace MuJoCo state estimator with IMU + encoder fusion',
          'Tune contact model to physical TALOS foot compliance',
          'Run S1–S3 on real hardware, report sim-to-real gap',
          'Extend Crocoddyl planner with learned residuals (test on S4–S5)',
          'Vision-based perception for unstructured terrain (S4 ext.)']
          } />
        
        <FutureCard
          status="LATER · Year 4–5"
          tone="future"
          level="L3"
          title="Benchmark + autonomy extensions"
          items={[
          'S6 — dynamic obstacle avoidance',
          'S7 — collaborative human + humanoid task',
          'Dual-arm manipulation with external object models',
          'Battery-life energy metrics on hardware',
          'End-to-end autonomous task execution']
          } />
        
      </div>

      <div style={{
        marginTop: 28, padding: '20px 32px',
        borderLeft: `4px solid ${C.accent}`, background: C.paperDk,
        fontFamily: F.serif, fontSize: 28, lineHeight: 1.3, color: C.ink, fontStyle: 'italic'
      }}>
        Every component is open-source, documented and modular. Future researchers <span style={{ color: C.accent, fontStyle: 'normal' }}>extend</span> — they do not <span style={{ color: C.accent, fontStyle: 'normal' }}>restart</span>.
      </div>
    </SlideFrame>);

}

function FutureCard({ status, tone, level, title, items }) {
  const palette = tone === 'ok' ? { bg: C.ink, fg: C.paperOnDeep, accent: C.ok } :
  tone === 'open' ? { bg: C.paperDk, fg: C.ink, accent: C.accent2 } :
  { bg: C.paperDk, fg: C.ink, accent: C.mute, dim: true };
  return (
    <div style={{
      background: palette.bg, color: palette.fg,
      padding: '28px 32px', position: 'relative',
      border: `1px solid ${C.ink}22`,
      opacity: palette.dim ? 0.85 : 1,
      display: 'flex', flexDirection: 'column', gap: 16
    }}>
      {tone === 'ok' && <CornerTicks color={C.accent} size={18} />}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div style={{ fontFamily: F.mono, fontSize: 16, letterSpacing: '0.16em', color: palette.accent, textTransform: 'uppercase' }}>
          {status}
        </div>
        <div style={{ fontFamily: F.mono, fontSize: 16, color: palette.fg === C.paperOnDeep ? '#ffffff80' : C.mute, letterSpacing: '0.06em' }}>{level}</div>
      </div>
      <div style={{ fontFamily: F.serif, fontSize: 36, lineHeight: 1.05 }}>
        {title}
      </div>
      <div style={{ borderTop: `1px solid ${palette.fg === C.paperOnDeep ? '#ffffff22' : C.ink + '22'}`, paddingTop: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {items.map((it, i) =>
        <div key={i} style={{ display: 'flex', gap: 12, fontFamily: F.sans, fontSize: 22, lineHeight: 1.35, opacity: 0.95 }}>
            <span style={{ color: palette.accent, fontFamily: F.mono, fontSize: 18, marginTop: 4 }}>—</span>
            <span>{it}</span>
          </div>
        )}
      </div>
    </div>);

}

// =========================================================
// SLIDE 15 — Progress to date
// =========================================================
function Slide15({ idx, total }) {
  const tasks = [
  { task: 'Literature review · Ch. 2 State of the Art', start: 'Apr 13', end: 'Apr 28', s: 0, e: 11 },
  { task: 'Bibliography audit · 33 refs verified, 7 fabricated removed', start: 'Apr 23', end: 'Apr 28', s: 7, e: 11 },
  { task: 'Phase 1 · 5 critical decisions locked', start: 'Apr 28', end: 'Apr 30', s: 11, e: 13 },
  { task: 'LaTeX thesis template (Overleaf)', start: 'Apr 28', end: 'Apr 30', s: 11, e: 13 },
  { task: 'Ch. 2 LaTeX corrections · 13 fake citations replaced', start: 'Apr 30', end: 'Apr 30', s: 13, e: 14 },
  { task: 'Overleaf zip rebuild v02', start: 'Apr 30', end: 'Apr 30', s: 13, e: 14 },
  { task: 'GitHub branch · chapter/2-state-of-the-art', start: 'Apr 30', end: 'Apr 30', s: 13, e: 14 }];


  return (
    <SlideFrame label="Section 6 · Plan" idx={idx} total={total}>
      <SectionEyebrow kicker="10 · What has shipped">Apr 13 → May 5</SectionEyebrow>
      <SlideTitle>Three weeks · the theoretical foundation is complete.</SlideTitle>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 56, marginTop: 44, alignItems: 'stretch' }}>
        <div style={{ background: C.paperDk, padding: '28px 32px', position: 'relative', width: "1394px" }}>
          <CornerTicks color={C.ok} size={18} />
          <div style={{ display: 'grid', gridTemplateColumns: '14px 1fr 60px 60px', gap: 16, padding: '0 0 12px', borderBottom: `2px solid ${C.ink}`, fontFamily: F.mono, fontSize: 14, letterSpacing: '0.14em', color: C.mute, textTransform: 'uppercase' }}>
            <div></div>
            <div>Task</div>
            <div>Start</div>
            <div>End</div>
          </div>
          {tasks.map((t, i) =>
          <div key={i} style={{ display: 'grid', gridTemplateColumns: '14px 1fr 60px 60px', gap: 16, padding: '12px 0', borderBottom: `1px solid ${C.ink}1a`, alignItems: 'center', opacity: "0" }}>
              <span style={{
              width: 14, height: 14, borderRadius: 2, background: C.ok,
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              color: '#fff', fontFamily: F.mono, fontSize: 11, opacity: "0"
            }}>
</span>
              <div style={{ fontFamily: F.sans, fontSize: 22, color: C.ink, lineHeight: 1.3 }}>{t.task}</div>
              <div style={{ fontFamily: F.mono, fontSize: 16, color: C.mute }}>{t.start}</div>
              <div style={{ fontFamily: F.mono, fontSize: 16, color: C.mute }}>{t.end}</div>
            </div>)}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
          <Stat big="7/7" sub="planned tasks completed on schedule" />
          <Stat big="33" sub="bibliography references audited & verified" tone="warn" />
          <Stat big="21%" sub="hallucination rate caught in initial bib — corrected before review" tone="bad" />
          <div style={{ ...{
              padding: '18px 24px', background: C.ink, color: C.paperOnDeep,
              fontFamily: F.serif, fontSize: 24, lineHeight: 1.3, position: 'relative', height: "36px"
            }, background: "rgba(15, 27, 45, 0)" }}>
            <div style={{ fontFamily: F.mono, fontSize: 14, letterSpacing: '0.16em', color: C.accent, textTransform: 'uppercase', marginBottom: 6 }}>

            </div>
            
          </div>
        </div>
      </div>
    </SlideFrame>);

}

window.Slide10 = Slide10;
window.Slide11 = Slide11;
window.Slide12 = Slide12;
window.Slide13 = Slide13;
window.Slide14 = Slide14;
window.Slide15 = Slide15;