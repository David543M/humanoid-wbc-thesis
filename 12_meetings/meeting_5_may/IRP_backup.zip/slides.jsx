/* eslint-disable */
// Design tokens — locked before any slide is written.
const TYPE_SCALE = {
  display: 120, // hero figures
  title: 64,
  subtitle: 44,
  body: 34,
  small: 28,
  micro: 22 // tag labels, footers, slide numbers
};

const SPACING = {
  paddingTop: 100,
  paddingBottom: 80,
  paddingX: 110,
  titleGap: 52,
  itemGap: 28
};

const C = {
  paper: '#F2EEE5', // warm off-white
  paperDk: '#E8E2D4',
  ink: '#0F1B2D', // deep navy
  ink2: '#2C3A52',
  rule: '#0F1B2D',
  mute: '#6B7585',
  accent: '#C04A2A', // signal orange-red (technical, not playful)
  accent2: '#1E5B7A', // engineering blue
  ok: '#3A7A4A',
  warn: '#B8862B',
  bad: '#A33A28',
  paperDeep: '#0F1B2D', // dark variant
  paperOnDeep: '#F2EEE5'
};

// Font stacks
const F = {
  serif: '"Instrument Serif", "Times New Roman", Georgia, serif',
  sans: '"IBM Plex Sans", "Helvetica Neue", Arial, sans-serif',
  mono: '"JetBrains Mono", "IBM Plex Mono", Menlo, monospace'
};

// ---------- Shared chrome ----------

function SlideFrame({ children, dark = false, label, idx, total, noPad = false, bg, style = {} }) {
  const bgColor = bg || (dark ? C.paperDeep : C.paper);
  const fg = dark ? C.paperOnDeep : C.ink;
  return (
    <div style={{
      width: 1920, height: 1080, position: 'relative',
      background: bgColor, color: fg,
      fontFamily: F.sans,
      overflow: 'hidden',
      ...style
    }}>
      {/* faint grid */}
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        backgroundImage: `linear-gradient(${dark ? 'rgba(242,238,229,0.04)' : 'rgba(15,27,45,0.04)'} 1px, transparent 1px), linear-gradient(90deg, ${dark ? 'rgba(242,238,229,0.04)' : 'rgba(15,27,45,0.04)'} 1px, transparent 1px)`,
        backgroundSize: '80px 80px'
      }} />
      <div style={{
        position: 'absolute',
        top: noPad ? 0 : SPACING.paddingTop,
        left: noPad ? 0 : SPACING.paddingX,
        right: noPad ? 0 : SPACING.paddingX,
        bottom: noPad ? 0 : SPACING.paddingBottom,
        display: 'flex', flexDirection: 'column'
      }}>
        {children}
      </div>
      <Chrome dark={dark} label={label} idx={idx} total={total} />
    </div>);

}

function Chrome({ dark, label, idx, total }) {
  const fg = dark ? 'rgba(242,238,229,0.55)' : 'rgba(15,27,45,0.50)';
  const rule = dark ? 'rgba(242,238,229,0.20)' : 'rgba(15,27,45,0.20)';
  return (
    <>
      {/* top hairline */}
      <div style={{ position: 'absolute', top: 44, left: SPACING.paddingX, right: SPACING.paddingX, height: 1, background: rule }} />
      {/* top-left mark */}
      <div style={{
        position: 'absolute', top: 16, left: SPACING.paddingX,
        fontFamily: F.mono, fontSize: TYPE_SCALE.micro, letterSpacing: '0.08em',
        color: fg, textTransform: 'uppercase'
      }}>

      </div>
      {/* top-right label */}
      <div style={{
        position: 'absolute', top: 16, right: SPACING.paddingX,
        fontFamily: F.mono, fontSize: TYPE_SCALE.micro, letterSpacing: '0.08em',
        color: fg, textTransform: 'uppercase'
      }}>
        {label}
      </div>
      {/* bottom hairline */}
      <div style={{ position: 'absolute', bottom: 44, left: SPACING.paddingX, right: SPACING.paddingX, height: 1, background: rule }} />
      {/* bottom-left */}
      <div style={{
        position: 'absolute', bottom: 16, left: SPACING.paddingX,
        fontFamily: F.mono, fontSize: TYPE_SCALE.micro, letterSpacing: '0.08em', color: fg
      }}>
        05 · MAY · 2026
      </div>
      {/* bottom-right */}
      <div style={{
        position: 'absolute', bottom: 16, right: SPACING.paddingX,
        fontFamily: F.mono, fontSize: TYPE_SCALE.micro, letterSpacing: '0.08em', color: fg
      }}>
        {String(idx).padStart(2, '0')} / {String(total).padStart(2, '0')}
      </div>
    </>);

}

function SectionEyebrow({ kicker, children, color }) {
  return (
    <div style={{
      fontFamily: F.mono, fontSize: TYPE_SCALE.micro,
      letterSpacing: '0.16em', textTransform: 'uppercase',
      color: color || C.accent, marginBottom: 24,
      display: 'flex', alignItems: 'center', gap: 16
    }}>
      <span style={{ width: 32, height: 1, background: color || C.accent }} />
      <span>{kicker}</span>
      {children && <><span style={{ opacity: 0.4 }}>·</span><span style={{ color: C.mute }}>{children}</span></>}
    </div>);

}

function SlideTitle({ children, size = TYPE_SCALE.title, color }) {
  return (
    <h1 style={{
      fontFamily: F.serif, fontWeight: 400,
      fontSize: size, lineHeight: 1.02, letterSpacing: '-0.015em',
      color: color || 'inherit', margin: 0,
      textWrap: 'balance'
    }}>{children}</h1>);

}

// ---------- Schematic helpers (decorative, lightweight) ----------

function CrossMark({ size = 14, color }) {
  return (
    <svg width={size} height={size} viewBox="0 0 14 14" style={{ flexShrink: 0 }}>
      <line x1="0" y1="7" x2="14" y2="7" stroke={color || C.ink} strokeWidth="1" />
      <line x1="7" y1="0" x2="7" y2="14" stroke={color || C.ink} strokeWidth="1" />
    </svg>);

}

function CornerTicks({ color = C.ink, size = 24, weight = 1 }) {
  const c = color,s = size,w = weight;
  return (
    <>
      <span style={{ position: 'absolute', top: 0, left: 0, width: s, height: w, background: c }} />
      <span style={{ position: 'absolute', top: 0, left: 0, width: w, height: s, background: c }} />
      <span style={{ position: 'absolute', top: 0, right: 0, width: s, height: w, background: c }} />
      <span style={{ position: 'absolute', top: 0, right: 0, width: w, height: s, background: c }} />
      <span style={{ position: 'absolute', bottom: 0, left: 0, width: s, height: w, background: c }} />
      <span style={{ position: 'absolute', bottom: 0, left: 0, width: w, height: s, background: c }} />
      <span style={{ position: 'absolute', bottom: 0, right: 0, width: s, height: w, background: c }} />
      <span style={{ position: 'absolute', bottom: 0, right: 0, width: w, height: s, background: c }} />
    </>);

}

// =========================================================
// SLIDE 1 — TITLE
// =========================================================
function Slide01({ idx, total }) {
  return (
    <SlideFrame label="Cover" idx={idx} total={total}>
      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1.35fr 1fr', gap: 60, alignItems: 'stretch', width: "1480px" }}>
        {/* LEFT — title block */}
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', paddingTop: 30, minWidth: 0, width: "821px" }}>
          <div>
            <div style={{
              fontFamily: F.mono, fontSize: TYPE_SCALE.micro,
              letterSpacing: '0.18em', textTransform: 'uppercase',
              color: C.accent, marginBottom: 36
            }}>
              Master's Thesis · Progress Meeting · 05 May 2026
            </div>
            <h1 style={{
              fontFamily: F.serif, fontWeight: 400,
              fontSize: 96, lineHeight: 0.98, letterSpacing: '-0.02em',
              color: C.ink, margin: 0
            }}>
              Whole-Body Control<br />
              for Humanoid Robots.
            </h1>
            <h2 style={{
              fontFamily: F.serif, fontStyle: 'italic', fontWeight: 400,
              fontSize: 54, lineHeight: 1.05, letterSpacing: '-0.01em',
              color: C.accent, margin: '28px 0 0 0'
            }}>
              A simulation-first foundation.
            </h2>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32, marginTop: 48 }}>
            <MetaBlock label="Candidate" lines={['David Mazé']} />
            <MetaBlock label="Supervision" lines={['Gilbert Tang', 'Phill Web']} />
            <MetaBlock label="Department" lines={['Cranfield University', 'Robotics MSc']} />
            <MetaBlock label="Submission" lines={['26 August 2026', <span key="d" style={{ color: C.accent }}>T − 16 weeks</span>]} />
          </div>

          <div style={{
            fontFamily: F.mono, fontSize: 18, color: C.mute,
            marginTop: 32, paddingTop: 16, borderTop: `1px solid ${C.ink}22`,
            letterSpacing: '0.04em', lineHeight: 1.5
          }}>
            Original title — <span style={{ color: C.ink }}>"Development &amp; Simulation of a Whole-Body Control Framework for a Humanoid Robot"</span>
          </div>
        </div>

        {/* RIGHT — schematic figure */}
        <div style={{ position: 'relative' }}>
          <CornerTicks color={C.ink} size={28} />
          <div style={{ position: 'absolute', inset: 0, display: 'grid', gridTemplateColumns: '1fr 1fr' }}>
            <BlueprintHumanoid />
            <MujocoFrame />
          </div>
          <div style={{
            position: 'absolute', bottom: 16, left: 16, right: 16,
            display: 'flex', justifyContent: 'space-between',
            fontFamily: F.mono, fontSize: 18, color: C.mute, letterSpacing: '0.1em', height: "60px"
          }}>
            <span>FIG. 0 — TALOS · 32 DOF</span>
            <span style={{ width: "193px", padding: "0.800049px", margin: "4.80005px", textAlign: "right", letterSpacing: "1.8px", height: "4px" }}>MUJOCO · 1 KHZ</span>
          </div>
        </div>
      </div>
    </SlideFrame>);

}

function MetaBlock({ label, lines }) {
  return (
    <div>
      <div style={{
        fontFamily: F.mono, fontSize: 18,
        letterSpacing: '0.16em', textTransform: 'uppercase',
        color: C.mute, marginBottom: 8
      }}>{label}</div>
      <div style={{ fontFamily: F.sans, fontSize: TYPE_SCALE.small, lineHeight: 1.3, color: C.ink }}>
        {lines.map((l, i) => <div key={i}>{l}</div>)}
      </div>
    </div>);

}

function BlueprintHumanoid() {
  // Stylized humanoid silhouette in blueprint style
  return (
    <div style={{ position: 'relative', borderRight: `1px solid ${C.ink}22` }}>
      <svg viewBox="0 0 300 600" preserveAspectRatio="xMidYMid meet" style={{ height: '100%', display: 'block', width: "389px" }}>
        {/* bg grid */}
        <defs>
          <pattern id="bp-grid" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M 20 0 L 0 0 0 20" fill="none" stroke={C.ink} strokeOpacity="0.08" strokeWidth="0.5" />
          </pattern>
        </defs>
        <rect width="300" height="600" fill="url(#bp-grid)" style={{ width: "300px" }} />

        {/* center axis */}
        <line x1="150" y1="20" x2="150" y2="580" stroke={C.ink} strokeOpacity="0.3" strokeDasharray="4 6" strokeWidth="0.8" />

        {/* head */}
        <circle cx="150" cy="80" r="34" fill="none" stroke={C.ink} strokeWidth="1.4" />
        <circle cx="150" cy="80" r="6" fill={C.accent} />
        {/* neck */}
        <line x1="150" y1="114" x2="150" y2="138" stroke={C.ink} strokeWidth="1.4" />
        {/* torso */}
        <rect x="108" y="138" width="84" height="130" fill="none" stroke={C.ink} strokeWidth="1.4" />
        <rect x="108" y="138" width="84" height="130" fill={C.ink} fillOpacity="0.04" />
        {/* shoulders + arms */}
        <line x1="108" y1="148" x2="70" y2="158" stroke={C.ink} strokeWidth="1.4" />
        <line x1="70" y1="158" x2="62" y2="240" stroke={C.ink} strokeWidth="1.4" />
        <line x1="62" y1="240" x2="56" y2="320" stroke={C.ink} strokeWidth="1.4" />
        <circle cx="70" cy="158" r="5" fill={C.paper} stroke={C.ink} strokeWidth="1.2" />
        <circle cx="62" cy="240" r="5" fill={C.paper} stroke={C.ink} strokeWidth="1.2" />
        <circle cx="56" cy="320" r="6" fill={C.accent} />

        <line x1="192" y1="148" x2="230" y2="158" stroke={C.ink} strokeWidth="1.4" />
        <line x1="230" y1="158" x2="238" y2="240" stroke={C.ink} strokeWidth="1.4" />
        <line x1="238" y1="240" x2="244" y2="320" stroke={C.ink} strokeWidth="1.4" />
        <circle cx="230" cy="158" r="5" fill={C.paper} stroke={C.ink} strokeWidth="1.2" />
        <circle cx="238" cy="240" r="5" fill={C.paper} stroke={C.ink} strokeWidth="1.2" />
        <circle cx="244" cy="320" r="6" fill={C.accent} />

        {/* pelvis */}
        <rect x="118" y="268" width="64" height="38" fill="none" stroke={C.ink} strokeWidth="1.4" />
        <circle cx="150" cy="287" r="4" fill={C.accent} />
        {/* legs */}
        <line x1="130" y1="306" x2="124" y2="430" stroke={C.ink} strokeWidth="1.4" />
        <line x1="124" y1="430" x2="120" y2="540" stroke={C.ink} strokeWidth="1.4" />
        <circle cx="124" cy="430" r="5" fill={C.paper} stroke={C.ink} strokeWidth="1.2" />
        <rect x="100" y="540" width="40" height="14" fill={C.ink} fillOpacity="0.1" stroke={C.ink} strokeWidth="1.2" />

        <line x1="170" y1="306" x2="176" y2="430" stroke={C.ink} strokeWidth="1.4" />
        <line x1="176" y1="430" x2="180" y2="540" stroke={C.ink} strokeWidth="1.4" />
        <circle cx="176" cy="430" r="5" fill={C.paper} stroke={C.ink} strokeWidth="1.2" />
        <rect x="160" y="540" width="40" height="14" fill={C.ink} fillOpacity="0.1" stroke={C.ink} strokeWidth="1.2" />

        {/* dimension marks */}
        <line x1="40" y1="46" x2="40" y2="554" stroke={C.ink} strokeOpacity="0.5" strokeWidth="0.8" />
        <line x1="36" y1="46" x2="44" y2="46" stroke={C.ink} strokeOpacity="0.5" strokeWidth="0.8" />
        <line x1="36" y1="554" x2="44" y2="554" stroke={C.ink} strokeOpacity="0.5" strokeWidth="0.8" />
        <text x="32" y="304" fontFamily="JetBrains Mono, monospace" fontSize="10" fill={C.mute} transform="rotate(-90 32 304)">1.75 M</text>

        {/* labels */}
        <text x="200" y="84" fontFamily="JetBrains Mono, monospace" fontSize="9" fill={C.mute}>HEAD · 2 DOF</text>
        <text x="200" y="200" fontFamily="JetBrains Mono, monospace" fontSize="9" fill={C.mute}>ARM · 7 DOF</text>
        <text x="200" y="380" fontFamily="JetBrains Mono, monospace" fontSize="9" fill={C.mute}>LEG · 6 DOF</text>
      </svg>
    </div>);

}

function MujocoFrame() {
  // Stylized MuJoCo simulation viewport
  return (
    <div style={{ position: 'relative', background: C.ink, color: C.paper }}>
      <svg viewBox="0 0 300 600" preserveAspectRatio="xMidYMid meet" style={{ height: '100%', display: 'block', width: "450px" }}>
        {/* sky/ground gradient */}
        <defs>
          <linearGradient id="sky" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor="#1a2942" />
            <stop offset="1" stopColor="#0F1B2D" />
          </linearGradient>
          <pattern id="floor-grid" width="30" height="20" patternUnits="userSpaceOnUse" patternTransform="skewX(-30)">
            <path d="M 0 0 L 30 0" stroke="#3a4a66" strokeWidth="0.8" />
            <path d="M 0 0 L 0 20" stroke="#3a4a66" strokeWidth="0.8" />
          </pattern>
        </defs>
        <rect width="300" height="600" fill="url(#sky)" style={{ width: "301px", height: "600px" }} />
        {/* perspective floor */}
        <polygon points="0,420 300,420 380,600 -80,600" fill="url(#floor-grid)" opacity="0.7" />
        <polygon points="0,420 300,420 380,600 -80,600" fill="#0F1B2D" opacity="0.3" />

        {/* simulated humanoid silhouette */}
        <g transform="translate(150 280)">
          <rect x="-22" y="0" width="44" height="60" rx="3" fill="#D9D2C2" opacity="0.95" />
          <circle cx="0" cy="-22" r="14" fill="#D9D2C2" />
          <rect x="-8" y="-30" width="16" height="6" fill={C.accent} />
          <rect x="-30" y="0" width="10" height="50" rx="3" fill="#A8A192" />
          <rect x="20" y="0" width="10" height="50" rx="3" fill="#A8A192" />
          <rect x="-16" y="60" width="12" height="60" rx="3" fill="#A8A192" />
          <rect x="4" y="60" width="12" height="60" rx="3" fill="#A8A192" />
          <rect x="-22" y="120" width="20" height="6" fill="#0a1320" />
          <rect x="2" y="120" width="20" height="6" fill="#0a1320" />
          {/* contact force visualizations */}
          <circle cx="-12" cy="123" r="10" fill={C.accent} opacity="0.35" />
          <circle cx="12" cy="123" r="10" fill={C.accent} opacity="0.35" />
          <line x1="-12" y1="123" x2="-12" y2="155" stroke={C.accent} strokeWidth="1.5" />
          <line x1="12" y1="123" x2="12" y2="155" stroke={C.accent} strokeWidth="1.5" />
        </g>

        {/* HUD */}
        <g fontFamily="JetBrains Mono, monospace" fontSize="11" fill="#9aa6bd">
          <text x="14" y="28">MUJOCO 3.1 · TALOS.XML</text>
          <text x="14" y="46">DT = 1.0 MS · STEPS 142,037</text>
          <text x="14" y="582">F_z(L) = 358 N   F_z(R) = 372 N</text>
          <text x="220" y="28" fill={C.accent}>● REC</text>
        </g>

        {/* crosshair */}
        <line x1="150" y1="320" x2="150" y2="340" stroke={C.accent} strokeWidth="0.8" />
        <line x1="140" y1="330" x2="160" y2="330" stroke={C.accent} strokeWidth="0.8" />
      </svg>
    </div>);

}

// =========================================================
// SLIDE 2 — 5-Year Program
// =========================================================
function Slide02({ idx, total }) {
  const years = [
  { y: 'Year 1', sub: '2026', label: 'Theoretical foundations', body: 'Literature, control formulation, simulation framework, evaluation protocol.', active: true },
  { y: 'Year 2', sub: '2027', label: 'Simulation maturity', body: 'Extended scenarios, sim-to-real preparation, second-generation control.' },
  { y: 'Year 3', sub: '2028', label: 'Hardware integration', body: 'Acquisition of TALOS-class hardware, first physical experiments.' },
  { y: 'Year 4', sub: '2029', label: 'First prototypes', body: 'Closed-loop control on real hardware, on-board perception, manipulation.' },
  { y: 'Year 5', sub: '2030', label: 'Autonomous humanoid', body: 'Integrated whole-body autonomy in unstructured environments.' }];


  return (
    <SlideFrame label="Section 1 · Context" idx={idx} total={total}>
      <SectionEyebrow kicker="01 · Programmatic context">5-year strategic plan</SectionEyebrow>
      <SlideTitle>The 5-year humanoid robotics program.</SlideTitle>
      <div style={{
        fontFamily: F.serif, fontStyle: 'italic',
        fontSize: TYPE_SCALE.subtitle, lineHeight: 1.2,
        color: C.ink2, marginTop: 28, maxWidth: 1500
      }}>
        This thesis is the <span style={{ color: C.accent }}>first academic output</span> of a long-term institutional program — so generality and reproducibility are the primary design constraints.
      </div>

      {/* Timeline */}
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', marginTop: 56 }}>
        <div style={{ width: '100%', position: 'relative' }}>
          {/* spine */}
          <div style={{ position: 'absolute', left: 0, right: 0, top: 90, height: 2, background: C.ink }} />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 24 }}>
            {years.map((p, i) =>
            <div key={i} style={{ position: 'relative', paddingTop: 0 }}>
                {/* node */}
                <div style={{
                width: p.active ? 32 : 18, height: p.active ? 32 : 18, borderRadius: '50%',
                background: p.active ? C.accent : C.paper,
                border: `2px solid ${C.ink}`,
                margin: `${p.active ? 76 : 83}px auto 0`,
                boxShadow: p.active ? `0 0 0 6px ${C.paper}, 0 0 0 7px ${C.accent}` : 'none'
              }} />
                {p.active &&
              <div style={{
                position: 'absolute', top: 32, left: '50%', transform: 'translateX(-50%)',
                fontFamily: F.mono, fontSize: 18, letterSpacing: '0.16em',
                color: C.accent, textTransform: 'uppercase', whiteSpace: 'nowrap'
              }}>▼ We are here</div>
              }
                <div style={{ marginTop: 28, textAlign: 'center', padding: '0 8px' }}>
                  <div style={{ fontFamily: F.mono, fontSize: 18, letterSpacing: '0.14em', color: C.mute, textTransform: 'uppercase' }}>
                    {p.sub}
                  </div>
                  <div style={{ fontFamily: F.serif, fontSize: 40, color: p.active ? C.accent : C.ink, marginTop: 4, lineHeight: 1 }}>
                    {p.y}
                  </div>
                  <div style={{ fontFamily: F.sans, fontSize: TYPE_SCALE.small, fontWeight: 600, color: C.ink, marginTop: 14 }}>
                    {p.label}
                  </div>
                  <div style={{ fontFamily: F.sans, fontSize: 22, color: C.ink2, marginTop: 10, lineHeight: 1.4 }}>
                    {p.body}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* footer key point */}
      <div style={{
        marginTop: 36, padding: '24px 32px',
        borderLeft: `4px solid ${C.accent}`,
        background: C.paperDk,
        fontFamily: F.serif, fontSize: TYPE_SCALE.body, lineHeight: 1.3, color: C.ink
      }}>
        No physical hardware exists yet. Every decision made now must be <span style={{ fontStyle: 'italic' }}>forward-compatible</span> — we are building the foundations the next researchers will inherit.
      </div>
    </SlideFrame>);

}

// =========================================================
// SLIDE 3 — Where this thesis fits
// =========================================================
function Slide03({ idx, total }) {
  return (
    <SlideFrame label="Section 1 · Context" idx={idx} total={total}>
      <SectionEyebrow kicker="02 · Position in the program">The bridge layer</SectionEyebrow>
      <SlideTitle>Where this thesis fits.</SlideTitle>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1.05fr 1fr', gap: 80, marginTop: 48, alignItems: 'center' }}>
        {/* LEFT — pyramid */}
        <div style={{ position: 'relative', height: 720 }}>
          {/* Top — autonomous (Year 5) */}
          <PyramidLayer
            top={0} left="22%" width="56%" height={170}
            level="L3 · Year 5"
            title="Autonomous humanoid system"
            body="Integrated cognition, perception, manipulation."
            tone="future" />
          
          {/* Mid — hardware (Year 3-4) */}
          <PyramidLayer
            top={195} left="11%" width="78%" height={200}
            level="L2 · Year 3–4"
            title="Hardware integration"
            body="Real TALOS · sim-to-real transfer · on-board perception."
            tone="future" />
          
          {/* Bottom — this thesis (Year 1) */}
          <PyramidLayer
            top={420} left="0%" width="100%" height={300}
            level="L1 · Year 1 · This thesis"
            title="Simulation framework + evaluation protocol"
            body="MPC + QP-WBC on TALOS in MuJoCo. Reproducible S1–S5 protocol. Open-source, modular, documented."
            tone="now" />
          
        </div>

        {/* RIGHT — design constraints */}
        <div>
          <div style={{
            fontFamily: F.mono, fontSize: TYPE_SCALE.micro,
            letterSpacing: '0.16em', textTransform: 'uppercase',
            color: C.mute, marginBottom: 20
          }}>
            Mandatory framework properties
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>
            <Prop n="01" name="Modular" body="Components swap as the hardware program evolves — physics engine, dynamics library, even the planner itself." />
            <Prop n="02" name="Reproducible" body="Every result reruns from a single command. Seeds, configs and metrics are version-controlled alongside the code." />
            <Prop n="03" name="Well-documented" body="Next researchers extend the framework — they do not restart it. README, tutorials, and inline derivations." />
          </div>
          <div style={{
            marginTop: 36, fontFamily: F.serif, fontStyle: 'italic',
            fontSize: 30, lineHeight: 1.35, color: C.ink2
          }}>Without this floor, hardware work has nothing to build on.

          </div>
        </div>
      </div>
    </SlideFrame>);

}

function PyramidLayer({ top, left, width, height, level, title, body, tone }) {
  const isNow = tone === 'now';
  return (
    <div style={{
      position: 'absolute', top, left, width, height,
      background: isNow ? C.ink : C.paperDk,
      color: isNow ? C.paperOnDeep : C.ink,
      border: `1px solid ${C.ink}`,
      padding: '20px 28px',
      display: 'flex', flexDirection: 'column', justifyContent: 'flex-start',
      gap: 8
    }}>
      <CornerTicks color={isNow ? C.accent : C.ink} size={18} />
      <div style={{
        fontFamily: F.mono, fontSize: 20, letterSpacing: '0.14em',
        color: isNow ? C.accent : C.mute, textTransform: 'uppercase', marginBottom: 10
      }}>{level}</div>
      <div style={{ fontFamily: F.serif, fontSize: isNow ? 42 : 30, lineHeight: 1.05 }}>
        {title}
      </div>
      <div style={{ fontFamily: F.sans, fontSize: isNow ? 24 : 20, lineHeight: 1.35, opacity: isNow ? 0.85 : 0.75 }}>
        {body}
      </div>
    </div>);

}

function Prop({ n, name, body }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '64px 1fr', gap: 20 }}>
      <div style={{
        fontFamily: F.mono, fontSize: 24, color: C.accent, letterSpacing: '0.04em',
        borderTop: `1px solid ${C.ink}`, paddingTop: 6
      }}>{n}</div>
      <div style={{ borderTop: `1px solid ${C.ink}`, paddingTop: 6 }}>
        <div style={{ fontFamily: F.serif, fontSize: 38, color: C.ink, lineHeight: 1.1 }}>{name}</div>
        <div style={{ fontFamily: F.sans, fontSize: TYPE_SCALE.small, color: C.ink2, marginTop: 6, lineHeight: 1.35 }}>
          {body}
        </div>
      </div>
    </div>);

}

window.Slide01 = Slide01;
window.Slide02 = Slide02;
window.Slide03 = Slide03;
window.SlideFrame = SlideFrame;
window.SectionEyebrow = SectionEyebrow;
window.SlideTitle = SlideTitle;
window.CornerTicks = CornerTicks;
window.TYPE_SCALE = TYPE_SCALE;
window.SPACING = SPACING;
window.C = C;
window.F = F;