/* eslint-disable */
// =========================================================
// SLIDE 4 — From broad topic to research question
// =========================================================
function Slide04({ idx, total }) {
  return (
    <SlideFrame label="Section 2 · Problem" idx={idx} total={total}>
      <SectionEyebrow kicker="03 · Refining the problem">From topic to question</SectionEyebrow>
      <SlideTitle>From broad topic to a precise research question.</SlideTitle>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 80px 1.5fr', gap: 0, marginTop: 56, alignItems: 'stretch' }}>
        {/* LEFT — original */}
        <div style={{
          background: C.paperDk, padding: '40px 36px',
          display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
          position: 'relative', filter: 'saturate(0.7)'
        }}>
          <div>
            <div style={{ fontFamily: F.mono, fontSize: 20, letterSpacing: '0.16em', color: C.mute, textTransform: 'uppercase' }}>
              Original topic
            </div>
            <div style={{ fontFamily: F.serif, fontSize: 40, lineHeight: 1.2, color: C.ink2, marginTop: 24, fontStyle: 'italic' }}>
              "Development &amp; simulation of a whole-body control model for a humanoid robot."
            </div>
          </div>
          <div style={{ marginTop: 32 }}>
            <div style={{ fontFamily: F.mono, fontSize: 18, letterSpacing: '0.14em', color: C.bad, textTransform: 'uppercase', marginBottom: 12 }}>
              Why this is not enough
            </div>
            <Issue text="Which whole-body control approach? (dozens exist)" />
            <Issue text="Which humanoid? Which simulator?" />
            <Issue text="What does success look like? How is it measured?" />
            <Issue text="No evaluation criterion → no way to know if we succeeded." />
          </div>
        </div>

        {/* ARROW */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg viewBox="0 0 80 60" style={{ width: 80, height: 60 }}>
            <line x1="6" y1="30" x2="68" y2="30" stroke={C.accent} strokeWidth="2" />
            <polyline points="58,18 70,30 58,42" fill="none" stroke={C.accent} strokeWidth="2" />
          </svg>
        </div>

        {/* RIGHT — refined */}
        <div style={{
          background: C.ink, color: C.paperOnDeep, padding: '40px 44px',
          position: 'relative',
          display: 'flex', flexDirection: 'column', justifyContent: 'space-between'
        }}>
          <CornerTicks color={C.accent} size={22} />
          <div>
            <div style={{ fontFamily: F.mono, fontSize: 20, letterSpacing: '0.16em', color: C.accent, textTransform: 'uppercase' }}>
              Refined research question
            </div>
            <div style={{ fontFamily: F.serif, fontSize: 42, lineHeight: 1.2, marginTop: 24 }}>
              Can a <span style={{ color: C.accent }}>two-layer MPC + QP-WBC</span> framework, implemented on <span style={{ color: C.accent }}>TALOS in MuJoCo</span>, be rigorously evaluated through a <span style={{ color: C.accent }}>reproducible scenario-based protocol</span> — and serve as a <span style={{ color: C.accent }}>reusable simulation foundation</span> for future hardware integration?
            </div>
          </div>
          <div style={{ marginTop: 28, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
            <Delta tag="Architecture" body="MPC + QP-WBC two-layer hierarchy" />
            <Delta tag="Platform" body="TALOS robot · MuJoCo simulator" />
            <Delta tag="Evaluation" body="Reproducible S1–S5 protocol" />
            <Delta tag="Long-term goal" body="Reusable foundation for the program" />
          </div>
        </div>
      </div>
    </SlideFrame>);

}

function Issue({ text }) {
  return (
    <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start', fontFamily: F.sans, fontSize: 26, color: C.ink2, lineHeight: 1.35, marginBottom: 8 }}>
      <span style={{ color: C.bad, fontFamily: F.mono, fontSize: 22, marginTop: 4 }}>×</span>
      <span>{text}</span>
    </div>);

}

function Delta({ tag, body }) {
  return (
    <div style={{ borderTop: `1px solid ${C.accent}66`, paddingTop: 10 }}>
      <div style={{ fontFamily: F.mono, fontSize: 16, letterSpacing: '0.16em', color: C.accent, textTransform: 'uppercase' }}>{tag}</div>
      <div style={{ fontFamily: F.sans, fontSize: 24, color: C.paperOnDeep, marginTop: 4, lineHeight: 1.3 }}>{body}</div>
    </div>);

}

// =========================================================
// SLIDE 5 — Why simulation-first
// =========================================================
function Slide05({ idx, total }) {
  return (
    <SlideFrame label="Section 2 · Problem" idx={idx} total={total}>
      <SectionEyebrow kicker="04 · Strategy">A design choice, not a limitation</SectionEyebrow>
      <SlideTitle>Why "simulation-first" is the right strategy.</SlideTitle>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 60, marginTop: 56, alignItems: 'stretch' }}>
        {/* SIM */}
        <Pane
          tag="Simulation environment"
          tone="light"
          attrs={[
          ['Cost', 'Negligible'],
          ['Iteration', 'Minutes'],
          ['Repeatability', '1.000'],
          ['Damage risk', 'None']]
          }
          body="Rapid iteration, parameter sweeps, and reproducible experiments without physical risk." />
        
        {/* HW */}
        <Pane
          tag="Real hardware (Year 3+)"
          tone="dark"
          attrs={[
          ['Cost', '€ 500k+'],
          ['Iteration', 'Days'],
          ['Repeatability', 'Drift'],
          ['Damage risk', 'High']]
          }
          body="Expensive, unforgiving, and unavailable during early-stage research." />
        
      </div>

      {/* sim-to-real arrow + invariants */}
      <div style={{ marginTop: 32, padding: '32px 40px', background: C.paperDk, borderLeft: `4px solid ${C.accent}` }}>
        <div style={{ display: 'grid', gridTemplateColumns: '0.7fr 2fr', gap: 40, alignItems: 'center' }}>
          <div>
            <div style={{ fontFamily: F.mono, fontSize: TYPE_SCALE.micro, letterSpacing: '0.16em', color: C.accent, textTransform: 'uppercase' }}>
              Sim-to-real transfer
            </div>
            <div style={{ fontFamily: F.serif, fontSize: 40, color: C.ink, marginTop: 6, lineHeight: 1.1 }}>
              A solved research problem<br />for locomotion.
            </div>
          </div>
          <div style={{ fontFamily: F.sans, fontSize: TYPE_SCALE.body, lineHeight: 1.35, color: C.ink2 }}>
            Domain randomization &amp; contact-model tuning bridge the gap. By design, only the <span style={{ color: C.accent, fontWeight: 600 }}>hardware-interface layer</span> changes when physical TALOS arrives — the MPC + QP-WBC stack is identical in sim and on real hardware.
          </div>
        </div>
      </div>
    </SlideFrame>);

}

function Pane({ tag, tone, attrs, body }) {
  const dark = tone === 'dark';
  return (
    <div style={{
      background: dark ? C.ink : C.paperDk,
      color: dark ? C.paperOnDeep : C.ink,
      padding: '40px 44px', position: 'relative',
      border: `1px solid ${dark ? C.ink : C.ink + '33'}`,
      display: 'flex', flexDirection: 'column', gap: 24
    }}>
      <CornerTicks color={dark ? C.accent : C.ink} size={20} />
      <div style={{ fontFamily: F.mono, fontSize: TYPE_SCALE.micro, letterSpacing: '0.16em', color: dark ? C.accent : C.mute, textTransform: 'uppercase' }}>
        {tag}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12, borderTop: `1px solid ${dark ? '#ffffff22' : C.ink + '33'}` }}>
        {attrs.map(([k, v], i) =>
        <div key={i} style={{
          padding: '14px 0',
          borderBottom: `1px solid ${dark ? '#ffffff14' : C.ink + '22'}`,
          display: 'flex', justifyContent: 'space-between', gap: 16
        }}>
            <span style={{ fontFamily: F.mono, fontSize: 20, color: dark ? '#ffffff80' : C.mute, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{k}</span>
            <span style={{ fontFamily: F.serif, fontSize: 32, color: dark ? C.paperOnDeep : C.ink }}>{v}</span>
          </div>
        )}
      </div>
      <div style={{ fontFamily: F.sans, fontSize: TYPE_SCALE.small, lineHeight: 1.4, opacity: 0.9 }}>
        {body}
      </div>
    </div>);

}

// =========================================================
// SLIDE 6 — 40 Years of WBC
// =========================================================
function Slide06({ idx, total }) {
  // years map 1985 -> 2026
  const Y0 = 1985,Y1 = 2026;
  const xOf = (y) => (y - Y0) / (Y1 - Y0) * 100;
  const bands = [
  { name: 'QP / Task-Priority', sub: 'mature · industry standard', start: 1987, end: 2026, color: C.accent2, y: 0 },
  { name: 'MPC-Based', sub: 'powerful · compute-heavy', start: 2013, end: 2026, color: C.accent, y: 1 },
  { name: 'Learning-Based', sub: 'fast-moving · sim-to-real', start: 2022, end: 2026, color: '#6E3F8E', y: 2 }];

  const events = [
  { y: 1987, b: 0, label: 'Khatib', detail: 'operational space' },
  { y: 2005, b: 0, label: 'Sentis & Khatib', detail: 'null-space hierarchy' },
  { y: 2014, b: 0, label: 'Escande', detail: 'hierarchical QP' },
  { y: 2016, b: 0, label: 'Del Prete', detail: 'TSID — used today' },
  { y: 2013, b: 1, label: 'Wensing & Orin', detail: 'first conic QP' },
  { y: 2016, b: 1, label: 'Koolen', detail: 'momentum control · Atlas' },
  { y: 2021, b: 1, label: 'Sleiman', detail: 'unified loco-manipulation' },
  { y: 2023, b: 1, label: 'Romualdi', detail: 'online centroidal NMPC' },
  { y: 2024, b: 2, label: 'Radosavovic', detail: 'RL on real humanoid' },
  { y: 2025, b: 2, label: 'ASAP', detail: 'residual WBC' },
  { y: 2025.5, b: 2, label: 'PolySim', detail: 'multi-sim randomization' }];


  const ticks = [1985, 1995, 2005, 2015, 2025];

  return (
    <SlideFrame label="Section 3 · Literature" idx={idx} total={total}>
      <SectionEyebrow kicker="05 · State of the art">40 years · 3 paradigms</SectionEyebrow>
      <SlideTitle>Forty years of whole-body control.</SlideTitle>

      <div style={{ flex: 1, marginTop: 56, position: 'relative', padding: '20px 40px 0' }}>
        {/* legend */}
        <div style={{ display: 'flex', gap: 56, marginBottom: 36, flexWrap: 'nowrap' }}>
          {bands.map((b, i) =>
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 14, whiteSpace: 'nowrap' }}>
              <span style={{ width: 28, height: 14, background: b.color, flexShrink: 0 }} />
              <span style={{ fontFamily: F.serif, fontSize: 26, color: C.ink, whiteSpace: 'nowrap' }}>{b.name}</span>
            </div>
          )}
        </div>

        {/* timeline */}
        <div style={{ position: 'relative', height: 460 }}>
          {/* axis ticks */}
          {ticks.map((t, i) =>
          <div key={i} style={{
            position: 'absolute', left: `${xOf(t)}%`, top: 0, bottom: 0, width: 1,
            background: `${C.ink}1a`
          }}>
              <div style={{
              position: 'absolute', bottom: -28, left: -24, width: 48, textAlign: 'center',
              fontFamily: F.mono, fontSize: 18, color: C.mute, letterSpacing: '0.08em'
            }}>{t}</div>
            </div>
          )}

          {/* bands */}
          {bands.map((b, i) => {
            const top = 30 + b.y * 130;
            return (
              <div key={i}>
                <div style={{
                  position: 'absolute', top, height: 96,
                  left: `${xOf(b.start)}%`, width: `${xOf(b.end) - xOf(b.start)}%`,
                  background: b.color, opacity: 0.92
                }} />
                {/* band start label OUTSIDE band */}
                <div style={{
                  position: 'absolute', top: top + 38, left: `calc(${xOf(b.start)}% - 70px)`,
                  fontFamily: F.mono, fontSize: 14, color: b.color, letterSpacing: '0.12em',
                  textTransform: 'uppercase', whiteSpace: 'nowrap'
                }}>{b.start} →</div>
                {/* events on this band — stagger vertical offsets and anchor edge tooltips */}
                {events.filter((e) => e.b === i).map((e, j, arr) => {
                  const left = `${xOf(e.y)}%`;
                  // Three-step stagger for tight clusters
                  const offsets = [-42, 92, -92, 142];
                  const off = offsets[j % offsets.length];
                  const isLast = j === arr.length - 1;
                  const isFirst = j === 0;
                  // Anchor right-edge tooltips so they don't fall off-slide
                  const anchor = isLast ? 'translateX(-95%)' : isFirst ? 'translateX(-5%)' : 'translateX(-50%)';
                  return (
                    <div key={j} style={{ position: 'absolute', top: top + 6, left, height: 84 }}>
                      <div style={{
                        position: 'absolute', top: 0, left: -1, width: 2, height: 84,
                        background: '#fff'
                      }} />
                      <div style={{
                        position: 'absolute',
                        top: off,
                        left: 0, transform: anchor,
                        background: C.paper, border: `1px solid ${C.ink}`,
                        padding: '3px 8px', whiteSpace: 'nowrap', zIndex: 2
                      }}>
                        <div style={{ fontFamily: F.serif, fontSize: 18, color: C.ink, lineHeight: 1.05 }}>{e.label}</div>
                        <div style={{ fontFamily: F.mono, fontSize: 11, color: C.mute, letterSpacing: '0.04em' }}>{Math.floor(e.y)}</div>
                      </div>
                    </div>);

                })}
              </div>);

          })}

          {/* "we are here" */}
          <div style={{
            position: 'absolute', top: -10, left: `${xOf(2026)}%`, transform: 'translateX(-50%)',
            fontFamily: F.mono, fontSize: 18, color: C.accent, letterSpacing: '0.16em', textTransform: 'uppercase'
          }}>2026 ▼</div>
          <div style={{
            position: 'absolute', top: 14, left: `${xOf(2026)}%`, bottom: -10, width: 2,
            background: C.accent
          }} />
        </div>

        {/* takeaway */}
        <div style={{
          marginTop: 32, fontFamily: F.serif, fontStyle: 'italic',
          fontSize: 30, color: C.ink2, lineHeight: 1.3
        }}>
          Each generation solves part of the problem — none subsumes the others. Our framework deliberately sits in the most-validated branch (model-based) while staying compatible with the newest one (learning-based).
        </div>
      </div>
    </SlideFrame>);

}

// =========================================================
// SLIDE 7 — Four points of consensus
// =========================================================
function Slide07({ idx, total }) {
  const cards = [
  {
    n: '01',
    title: 'Centroidal dynamics suffice for planning.',
    body: 'A 32-DoF body abstracts to a 6-DoF centroidal model for trajectory planning. Every major framework does this; full-body planning adds compute with no empirical benefit at control rates.',
    cite: 'Orin et al. 2013'
  },
  {
    n: '02',
    title: 'Hierarchical QP is the dominant execution paradigm.',
    body: 'Strict task priority — "don\'t fall" beats "track the arm" — plus inequality constraints (joint limits, friction cones) make QP-WBC the industry-standard execution layer.',
    cite: 'Escande 2014 · Del Prete 2016'
  },
  {
    n: '03',
    title: 'Contact stability requires QP wrench distribution.',
    body: 'Whether the contact model is rigid or compliant, all serious WBC systems solve a QP to distribute forces across contacts and enforce friction-cone constraints.',
    cite: 'Righetti 2013 · Saab 2013'
  },
  {
    n: '04',
    title: 'The sim-to-real gap persists for contact-rich tasks.',
    body: 'Domain randomization handles flat-ground walking. Stair climbing and sustained-contact manipulation remain unsolved in simulation-to-hardware transfer.',
    cite: 'ASAP 2025 · PolySim 2025'
  }];


  return (
    <SlideFrame label="Section 3 · Literature" idx={idx} total={total}>
      <SectionEyebrow kicker="06 · What the field agrees on">Four invariants</SectionEyebrow>
      <SlideTitle>Four points of consensus.</SlideTitle>
      <div style={{
        fontFamily: F.serif, fontStyle: 'italic',
        fontSize: 32, color: C.ink2, marginTop: 24, maxWidth: 1500, lineHeight: 1.3
      }}>
        Across three paradigms and four decades, the community has converged on these — they are the non-negotiables our framework must respect.
      </div>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', gridTemplateRows: '1fr 1fr', gap: 28, marginTop: 44 }}>
        {cards.map((c, i) =>
        <ConsensusCard key={i} {...c} />
        )}
      </div>
    </SlideFrame>);

}

function ConsensusCard({ n, title, body, cite }) {
  return (
    <div style={{
      background: C.paperDk, padding: '28px 36px',
      borderTop: `2px solid ${C.ink}`,
      display: 'flex', flexDirection: 'column', position: 'relative'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div style={{ fontFamily: F.mono, fontSize: 20, letterSpacing: '0.14em', color: C.accent }}>
          {n} · CONSENSUS
        </div>
        <div style={{ fontFamily: F.mono, fontSize: 16, color: C.mute, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
          {cite}
        </div>
      </div>
      <div style={{ fontFamily: F.serif, fontSize: 38, lineHeight: 1.1, color: C.ink, marginTop: 14 }}>
        {title}
      </div>
      <div style={{ fontFamily: F.sans, fontSize: 26, color: C.ink2, lineHeight: 1.4, marginTop: 14 }}>
        {body}
      </div>
    </div>);

}

// =========================================================
// SLIDE 8 — Reproducibility problem
// =========================================================
function Slide08({ idx, total }) {
  const rows = [
  { paper: 'Koolen 2016', robot: 'Atlas', sim: 'custom', scen: 'Balance', metric: 'ZMP margin' },
  { paper: 'Sleiman 2021', robot: 'ANYmal', sim: 'RaiSim', scen: 'Walking', metric: 'CoT' },
  { paper: 'Romualdi 2023', robot: 'iCub', sim: 'Gazebo', scen: 'Push recovery', metric: 'Recovery time' },
  { paper: 'ASAP 2025', robot: 'Unitree H1', sim: 'IsaacGym', scen: 'Locomotion', metric: 'RL reward' },
  { paper: 'PolySim 2025', robot: '?', sim: 'multi', scen: '?', metric: '?' }];


  return (
    <SlideFrame label="Section 3 · Literature" idx={idx} total={total}>
      <SectionEyebrow kicker="07 · The methodological gap" color={C.bad}>The reproducibility crisis</SectionEyebrow>
      <SlideTitle>The reproducibility problem in WBC.</SlideTitle>
      <div style={{
        fontFamily: F.serif, fontStyle: 'italic',
        fontSize: 32, color: C.ink2, marginTop: 24, maxWidth: 1500, lineHeight: 1.3
      }}>
        You cannot compare papers because everyone uses a different robot, simulator, scenario and metric. This is the field's biggest unsolved <span style={{ color: C.bad }}>methodological</span> problem.
      </div>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 56, marginTop: 40, alignItems: 'stretch' }}>
        {/* table */}
        <div style={{ background: C.paperDk, padding: 24, position: 'relative' }}>
          <CornerTicks color={C.bad} size={18} />
          <div style={{ fontFamily: F.mono, fontSize: 18, letterSpacing: '0.16em', color: C.bad, textTransform: 'uppercase', marginBottom: 14 }}>
            Current state of WBC evaluation
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: F.sans }}>
            <thead>
              <tr style={{ borderBottom: `2px solid ${C.ink}` }}>
                {['Paper', 'Robot', 'Simulator', 'Scenario', 'Metric'].map((h, i) =>
                <th key={i} style={{
                  textAlign: 'left', padding: '12px 14px',
                  fontFamily: F.mono, fontSize: 18, color: C.mute,
                  letterSpacing: '0.14em', textTransform: 'uppercase', fontWeight: 500
                }}>{h}</th>
                )}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) =>
              <tr key={i} style={{ borderBottom: `1px solid ${C.ink}22` }}>
                  <td style={{ padding: '14px 14px', fontFamily: F.serif, fontSize: 26, color: C.ink }}>{r.paper}</td>
                  <td style={tdStyle(r.robot)}>{r.robot}</td>
                  <td style={tdStyle(r.sim)}>{r.sim}</td>
                  <td style={tdStyle(r.scen)}>{r.scen}</td>
                  <td style={tdStyle(r.metric)}>{r.metric}</td>
                </tr>
              )}
            </tbody>
          </table>
          <div style={{
            display: 'flex', gap: 20, marginTop: 18, paddingTop: 14, borderTop: `1px solid ${C.ink}22`,
            fontFamily: F.mono, fontSize: 16, color: C.mute, letterSpacing: '0.06em'
          }}>
            <span><span style={{ color: C.bad }}>?</span> = not reported · units inconsistent · scenarios non-standardized</span>
          </div>
        </div>

        {/* takeaway column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          <Stat big="0" sub="papers using the same robot + sim + scenario + metric set" />
          <Stat big="5" sub="different simulators across these 5 papers" tone="warn" />
          <Stat big="∅" sub="cross-paper benchmarks · comparison is impossible" tone="bad" />
          <div style={{
            marginTop: 8, padding: '20px 24px',
            background: C.ink, color: C.paperOnDeep,
            fontFamily: F.serif, fontSize: 24, lineHeight: 1.3
          }}>
            Researchers can't tell if controller A is <span style={{ color: C.accent }}>better</span> than B — or just <span style={{ color: C.accent }}>tested on an easier scenario</span>.
          </div>
        </div>
      </div>
    </SlideFrame>);

}

function tdStyle(v) {
  const missing = v === '?';
  return {
    padding: '14px 14px',
    fontFamily: F.sans, fontSize: 24,
    color: missing ? C.bad : C.ink2,
    fontStyle: missing ? 'italic' : 'normal'
  };
}

function Stat({ big, sub, tone }) {
  const color = tone === 'bad' ? C.bad : tone === 'warn' ? C.warn : C.accent;
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 18, paddingBottom: 14, borderBottom: `1px solid ${C.ink}33`, opacity: "0" }}>
      <div style={{ fontFamily: F.serif, fontSize: 96, color, lineHeight: 0.9 }}>{big}</div>
      <div style={{ fontFamily: F.sans, fontSize: 22, color: C.ink2, lineHeight: 1.3 }}>{sub}</div>
    </div>);

}

// =========================================================
// SLIDE 9 — Decision 1: Robot
// =========================================================
function Slide09({ idx, total }) {
  const options = [
  { name: 'Unitree H1/G1', tag: 'Position-controlled', pros: ['Popular in RL'], cons: ['Not torque-controlled', 'Limited dynamics access'], status: 'reject' },
  { name: 'Boston Dynamics Atlas', tag: 'Closed-source', pros: ['Industry benchmark'], cons: ['No public URDF', 'Not reproducible'], status: 'reject' },
  { name: 'Custom simplified', tag: 'Toy model', pros: ['Quick to build'], cons: ['Too abstract', 'Not transferable'], status: 'reject' },
  { name: 'TALOS · PAL Robotics', tag: '32 DoF · torque-controlled', pros: ['Open URDF', 'Pinocchio-compatible', 'Used in WBC literature', 'Likely Year-3 platform'], cons: [], status: 'choose' }];


  return (
    <SlideFrame label="Section 4 · Decisions" idx={idx} total={total}>
      <SectionEyebrow kicker="Decision 1 of 4">The robot</SectionEyebrow>
      <SlideTitle>TALOS — the only realistic, fully torque-controlled platform.</SlideTitle>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20, marginTop: 48 }}>
        {options.map((o, i) => <OptionCard key={i} {...o} />)}
      </div>

      <div style={{
        marginTop: 28, padding: 0,
        background: C.ink, color: C.paperOnDeep,
        display: 'grid', gridTemplateColumns: '220px 1fr auto', gap: 0, alignItems: 'stretch',
        position: 'relative'
      }}>
        {/* TALOS photo */}
        <div style={{
          background: '#0d1420', display: 'flex', alignItems: 'center', justifyContent: 'center',
          padding: '12px 16px', borderRight: `1px solid ${C.accent}40`, fontSize: "16px", width: "347px", height: "417px"
        }}>
          <img src="img/talos.webp" alt="TALOS humanoid" style={{
            display: 'block', objectFit: "fill", width: "250px", height: "470px"
          }} />
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, justifyContent: 'center', padding: "22px 0px 22px 148.8px", width: "1301px" }}>
          <div style={{ fontFamily: F.mono, fontSize: 16, color: C.accent, letterSpacing: '0.16em', textTransform: 'uppercase' }}>
            Why TALOS
          </div>
          <div style={{ fontFamily: F.serif, fontSize: 26, lineHeight: 1.25 }}>
            Full Pinocchio dynamic model · torque control compatible with QP-WBC <em>and</em> direct RL · community-validated in WBC papers · most likely starting point when university hardware arrives.
          </div>
        </div>
        <div style={{
          padding: '22px 32px', display: 'flex', flexDirection: 'column', gap: 8,
          alignItems: 'flex-end', justifyContent: 'center',
          borderLeft: `1px solid ${C.accent}40`
        }}>
          <div style={{ fontFamily: F.mono, fontSize: 22, color: C.accent, letterSpacing: '0.1em' }}>
            32 DOF
          </div>
          <div style={{ fontFamily: F.mono, fontSize: 12, color: '#ffffff80', letterSpacing: '0.14em', textTransform: 'uppercase' }}>
            PAL Robotics
          </div>
        </div>
      </div>
    </SlideFrame>);

}

function OptionCard({ name, tag, pros, cons, status }) {
  const chosen = status === 'choose';
  return (
    <div style={{
      background: chosen ? C.ink : C.paperDk,
      color: chosen ? C.paperOnDeep : C.ink,
      padding: '24px 26px',
      position: 'relative',
      filter: chosen ? 'none' : 'saturate(0.7)',
      opacity: chosen ? 1 : 0.85,
      display: 'flex', flexDirection: 'column', gap: 14,
      border: chosen ? `2px solid ${C.accent}` : `1px solid ${C.ink}22`, height: "300px"
    }}>
      {chosen && <CornerTicks color={C.accent} size={18} />}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div style={{
          fontFamily: F.mono, fontSize: 16, letterSpacing: '0.16em',
          color: chosen ? C.accent : C.mute, textTransform: 'uppercase'
        }}>
          {chosen ? '✓ chosen' : '× rejected'}
        </div>
      </div>
      <div style={{ fontFamily: F.serif, fontSize: 32, lineHeight: 1.05, color: chosen ? C.paperOnDeep : C.ink }}>
        {name}
      </div>
      <div style={{ fontFamily: F.mono, fontSize: 16, letterSpacing: '0.08em', color: chosen ? '#ffffffaa' : C.mute, textTransform: 'uppercase' }}>
        {tag}
      </div>
      <div style={{ borderTop: `1px solid ${chosen ? '#ffffff22' : C.ink + '22'}`, paddingTop: 12, display: 'flex', flexDirection: 'column', gap: 6 }}>
        {pros.map((p, i) =>
        <div key={i} style={{ display: 'flex', gap: 8, fontFamily: F.sans, fontSize: 20, lineHeight: 1.3 }}>
            <span style={{ color: chosen ? C.accent : C.ok, fontFamily: F.mono }}>+</span>
            <span style={{ opacity: 0.9 }}>{p}</span>
          </div>
        )}
        {cons.map((c, i) =>
        <div key={i} style={{ display: 'flex', gap: 8, fontFamily: F.sans, fontSize: 20, lineHeight: 1.3 }}>
            <span style={{ color: C.bad, fontFamily: F.mono }}>−</span>
            <span style={{ opacity: 0.9 }}>{c}</span>
          </div>
        )}
      </div>
    </div>);

}

window.Slide04 = Slide04;
window.Slide05 = Slide05;
window.Slide06 = Slide06;
window.Slide07 = Slide07;
window.Slide08 = Slide08;
window.Slide09 = Slide09;
window.OptionCard = OptionCard;