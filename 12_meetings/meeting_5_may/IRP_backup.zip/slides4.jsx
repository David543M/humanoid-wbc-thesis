/* eslint-disable */
// =========================================================
// SLIDE 16 — Gantt May 5 → Aug 26
// =========================================================
function Slide16({ idx, total }) {
  // 16 weeks: weeks 0..16 starting May 5
  const W = 16;
  const tasks = [
  { phase: 'Writing', name: 'Ch. 1 · Introduction', s: 0, e: 2.2, c: C.accent2 },
  { phase: 'Writing', name: 'Ch. 3 · Methodology (QP-WBC formulation)', s: 0, e: 3.0, c: C.accent2 },
  { phase: 'Admin', name: 'GitHub push + final bib fixes', s: 0, e: 0.5, c: C.mute },
  { phase: 'Simulation', name: 'Environment setup · TALOS + MuJoCo + Pinocchio', s: 2.2, e: 5.7, c: '#1E5B7A' },
  { phase: 'Experiments', name: 'S1–S3 · Balance, Walking, Push Recovery', s: 5.7, e: 9.2, c: '#6E3F8E' },
  { phase: 'Experiments', name: 'S4–S5 · Stair Climbing, Manipulation', s: 8.6, e: 11.6, c: '#6E3F8E' },
  { phase: 'Writing', name: 'Ch. 4–5 · Simulation & Results', s: 9.2, e: 13.2, c: C.accent2 },
  { phase: 'Writing', name: 'Ch. 6–7 · Discussion & Conclusion', s: 12.0, e: 14.5, c: C.accent2 },
  { phase: 'Review', name: 'Final review · proofreading · buffer', s: 14.5, e: 16, c: C.bad }];

  const milestones = [
  { w: 5.7, label: 'Jun 15 · sim env' },
  { w: 9.2, label: 'Jul 10 · S1–S3 done' },
  { w: 11.6, label: 'Jul 25 · all scenarios' },
  { w: 14.5, label: 'Aug 14 · full draft' }];

  const monthMarks = [
  { w: 0, label: 'MAY 5' },
  { w: 3.5, label: 'JUN 1' },
  { w: 7.8, label: 'JUL 1' },
  { w: 12.2, label: 'AUG 1' },
  { w: 16, label: 'AUG 26' }];


  return (
    <SlideFrame label="Section 6 · Plan" idx={idx} total={total}>
      <SectionEyebrow kicker="11 · Roadmap">16 weeks · 9 work packages · 4 milestones</SectionEyebrow>
      <SlideTitle>Roadmap to 26 August.</SlideTitle>

      <div style={{ flex: 1, marginTop: 36, display: 'flex', flexDirection: 'column' }}>
        {/* phase legend */}
        <div style={{ display: 'flex', gap: 28, marginBottom: 16, fontFamily: F.mono, fontSize: 16, color: C.mute, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
          <Legend color={C.accent2} label="Writing" />
          <Legend color="#1E5B7A" label="Simulation" />
          <Legend color="#6E3F8E" label="Experiments" />
          <Legend color={C.bad} label="Review" />
          <Legend color={C.mute} label="Admin" />
        </div>

        {/* gantt table */}
        <div style={{ flex: 1, background: C.paperDk, padding: '24px 28px', position: 'relative' }}>
          <CornerTicks color={C.ink} size={18} />
          <div style={{ display: 'grid', gridTemplateColumns: '180px 1fr', gap: 24 }}>
            {/* header */}
            <div></div>
            <div style={{ position: 'relative', height: 26 }}>
              {monthMarks.map((m, i) =>
              <div key={i} style={{
                position: 'absolute', left: `${m.w / W * 100}%`, top: 0,
                transform: 'translateX(-50%)',
                fontFamily: F.mono, fontSize: 16, color: C.mute, letterSpacing: '0.12em'
              }}>{m.label}</div>
              )}
            </div>
            {/* rows */}
            {tasks.map((t, i) =>
            <React.Fragment key={i}>
                <div style={{ fontFamily: F.mono, fontSize: 14, letterSpacing: '0.14em', color: C.mute, textTransform: 'uppercase', display: 'flex', alignItems: 'center', borderTop: `1px solid ${C.ink}1a`, paddingTop: 10 }}>
                  {t.phase}
                </div>
                <div style={{ position: 'relative', height: 36, borderTop: `1px solid ${C.ink}1a`, paddingTop: 10 }}>
                  {/* week grid */}
                  {Array.from({ length: W + 1 }).map((_, w) =>
                <div key={w} style={{
                  position: 'absolute', left: `${w / W * 100}%`, top: 0, bottom: 0, width: 1,
                  background: w % 4 === 0 ? `${C.ink}22` : `${C.ink}10`
                }} />
                )}
                  {/* bar */}
                  <div style={{ ...{
                    position: 'absolute',
                    left: `${t.s / W * 100}%`,
                    width: `${(t.e - t.s) / W * 100}%`,
                    top: 12, height: 22, background: t.c,
                    display: 'flex', alignItems: 'center', paddingLeft: 10,
                    fontFamily: F.sans, fontSize: 14, color: '#fff', whiteSpace: 'nowrap', overflow: 'hidden', padding: "0px"
                  }, width: "1197px" }}>
                    {t.name}
                  </div>
                </div>
              </React.Fragment>
            )}
          </div>

          {/* today + deadline */}
          <div style={{ position: 'absolute', left: `calc(180px + 28px + ${0 / W})`, top: 24, bottom: 24,
            marginLeft: 0, pointerEvents: 'none' }}>
          </div>
          {/* milestones strip */}
          <div style={{ display: 'grid', gridTemplateColumns: '180px 1fr', gap: 24, marginTop: 16 }}>
            <div style={{ fontFamily: F.mono, fontSize: 14, color: C.accent, letterSpacing: '0.14em', textTransform: 'uppercase' }}>Milestones</div>
            <div style={{ position: 'relative', height: 60 }}>
              {milestones.map((m, i) =>
              <div key={i} style={{
                position: 'absolute', left: `${m.w / W * 100}%`, top: 0,
                transform: 'translateX(-50%)', textAlign: 'center', whiteSpace: 'nowrap'
              }}>
                  <div style={{ width: 0, height: 0, borderLeft: '8px solid transparent', borderRight: '8px solid transparent', borderBottom: `12px solid ${C.accent}`, margin: '0 auto' }} />
                  <div style={{ fontFamily: F.mono, fontSize: 14, color: C.accent, letterSpacing: '0.08em', marginTop: 6, textTransform: 'uppercase' }}>{m.label}</div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* milestones already shown on the gantt itself; bottom callouts removed to avoid chrome collision */}
      </div>
    </SlideFrame>);

}

// =========================================================
// SLIDE 17 — Three asks
// =========================================================
function Slide17({ idx, total }) {
  const asks = [
  {
    n: '01',
    title: 'Research-question validation',
    body: 'Is the refined RQ — "reproducible scenario-based evaluation protocol as a reusable foundation" — the right angle for the program\'s Year-1 output?',
    tag: 'Framing'
  },
  {
    n: '02',
    title: 'S1–S5 scenario scope',
    body: 'Are the five scenarios realistic for a single master\'s thesis? Should S5 (loco-manipulation) be de-risked to an optional extension?',
    tag: 'Scope'
  },
  {
    n: '03',
    title: 'Deliverable expectations',
    body: 'Are the expected deliverables — framework + protocol + documented code + thesis — aligned with what the program needs for Year-3 hardware integration?',
    tag: 'Output'
  }];

  return (
    <SlideFrame label="Closing" idx={idx} total={total}>
      <SectionEyebrow kicker="12 · Closing">What we need from you</SectionEyebrow>
      <SlideTitle>Three asks before implementation begins.</SlideTitle>
      <div style={{ fontFamily: F.serif, fontStyle: 'italic', fontSize: 32, color: C.ink2, marginTop: 24, maxWidth: 1500, lineHeight: 1.3 }}>
        Implementation begins 20 May. Locking these three points now keeps the next 16 weeks on track.
      </div>

      <div style={{ flex: 1, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 32, marginTop: 56 }}>
        {asks.map((a, i) => <AskCard key={i} {...a} />)}
      </div>
    </SlideFrame>);

}

function AskCard({ n, title, body, tag }) {
  return (
    <div style={{
      background: C.ink, color: C.paperOnDeep,
      padding: '36px 36px 32px',
      position: 'relative', display: 'flex', flexDirection: 'column',
      border: `2px solid ${C.accent}`
    }}>
      <CornerTicks color={C.accent} size={20} />
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div style={{ fontFamily: F.serif, fontSize: 96, color: C.accent, lineHeight: 0.9 }}>{n}</div>
        <div style={{ fontFamily: F.mono, fontSize: 16, color: '#ffffff80', letterSpacing: '0.16em', textTransform: 'uppercase' }}>{tag}</div>
      </div>
      <div style={{ fontFamily: F.serif, fontSize: 38, color: C.paperOnDeep, lineHeight: 1.05, marginTop: 18 }}>
        {title}
      </div>
      <div style={{ fontFamily: F.sans, fontSize: 24, color: '#ffffffcc', lineHeight: 1.4, marginTop: 18, paddingTop: 18, borderTop: '1px solid #ffffff22' }}>
        {body}
      </div>
    </div>);

}

// =========================================================
// SLIDE 18 — Summary
// =========================================================
function Slide18({ idx, total }) {
  const items = [
  { n: '01', tag: 'Context', title: 'First thesis in a 5-year humanoid robotics program', body: 'Generality and reproducibility are the primary constraints — not optional refinements.' },
  { n: '02', tag: 'Problem', title: 'Reproducible simulation-first WBC framework for TALOS', body: 'A foundation that future hardware teams can transplant without re-deriving the stack.' },
  { n: '03', tag: 'Architecture', title: 'Two-layer MPC (Crocoddyl) + QP-WBC (TSID) on MuJoCo', body: 'Open-source, modular, theoretically grounded — and validated on Atlas, HRP-4, ANYmal.' },
  { n: '04', tag: 'Novelty', title: 'S1–S5 standardized evaluation protocol', body: 'The missing baseline in WBC research — fixed scenarios, fixed metrics, comparable results.' },
  { n: '05', tag: 'Timeline', title: 'Theory complete · implementation 20 May · submission 26 Aug', body: '7 / 7 planned tasks delivered on schedule. 16 weeks remain. 4 milestones tracked.' }];

  return (
    <SlideFrame label="Summary" idx={idx} total={total} dark>
      <SectionEyebrow kicker="13 · Recap" color={C.accent}>One slide to leave on screen</SectionEyebrow>
      <SlideTitle color={C.paperOnDeep}>Five takeaways.</SlideTitle>

      <div style={{ flex: 1, display: 'grid', gridTemplateRows: 'repeat(5, 1fr)', gap: 12, marginTop: 36 }}>
        {items.map((it, i) =>
        <div key={i} style={{
          display: 'grid', gridTemplateColumns: '80px 180px 1fr 1.4fr', gap: 24,
          padding: '16px 22px', alignItems: 'center',
          background: '#ffffff08', borderLeft: `3px solid ${C.accent}`
        }}>
            <div style={{ fontFamily: F.serif, fontSize: 56, color: C.accent, lineHeight: 0.9 }}>{it.n}</div>
            <div style={{ fontFamily: F.mono, fontSize: 16, letterSpacing: '0.18em', color: '#ffffff90', textTransform: 'uppercase' }}>{it.tag}</div>
            <div style={{ fontFamily: F.serif, fontSize: 26, color: C.paperOnDeep, lineHeight: 1.1 }}>{it.title}</div>
            <div style={{ fontFamily: F.sans, fontSize: 20, color: '#ffffffaa', lineHeight: 1.35 }}>{it.body}</div>
          </div>
        )}
      </div>

      <div style={{
        marginTop: 14, paddingTop: 14, borderTop: '1px solid #ffffff22',
        display: 'flex', justifyContent: 'space-between', alignItems: 'baseline'
      }}>
        <div style={{ fontFamily: F.serif, fontStyle: 'italic', fontSize: 22, color: '#ffffffcc', whiteSpace: 'nowrap' }}>
          Thank you.
        </div>
        <div style={{ fontFamily: F.mono, fontSize: 14, color: '#ffffff80', letterSpacing: '0.16em', textTransform: 'uppercase' }}>
          Submission · 26 Aug 2026
        </div>
      </div>
    </SlideFrame>);

}

window.Slide16 = Slide16;
window.Slide17 = Slide17;
window.Slide18 = Slide18;